#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

struct thread_param{
	int index;
};
void *PrintHello(void *threadid)
{
   long id;
   id = ((struct thread_param*) threadid)->index;
   printf("Hello World from thread %ld!\n", id);
   pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
   pthread_t threads[10];
   int rc;
   long i;
   struct thread_param thread[10];
   for(i = 0; i < 10; i++){
     thread[i].index = i;
     rc = pthread_create(&threads[i], NULL, PrintHello, &thread[i]);
     if (rc){
       printf("ERROR");
       exit(-1);
       }
     }
for(i = 0; i < 10; i++){
	   pthread_join(threads[i],NULL);
}

   pthread_exit(NULL);
}
