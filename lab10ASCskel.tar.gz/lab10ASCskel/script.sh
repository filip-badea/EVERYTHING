./build/lab10_bin -cwd -b y
