#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>	//headere incluse pt inet_ntoa
#include <netinet/in.h>
#include <arpa/inet.h>




/*inet aton - transforma dintr un string intr un struct in_addr

struct hostent {
	char *h_name,
	char **h_aliases,
	int h_addrtype,    //AF_INET
	int h_length;
	char **h_addr_list;
}*/



int main(int argc, char *argv[]) {


	if(strcmp(argv[1], "-n") == 0) {

		struct hostent * host = gethostbyname(argv[2]);  //VARIANTA PORNIRE CU NUME


		if(host == NULL)
			perror("Nu e host ul bun");
		else {

			int i = 0;
			printf("Numele referentiat : %s \n", host->h_name);
			for(i = 0; host->h_aliases[i] != NULL; i++)
				printf("%s \n", host->h_aliases[i]);


			struct in_addr **addr = (struct in_addr**)host->h_addr_list; // facem cast de la lista din 
			//hostent la un struct in_addr

			for(i = 0; addr[i] != NULL; i++)
				printf("%s \n", inet_ntoa(*addr[i]));		//aflare ip uri
		}


	}
	else {

//VARIANTA B CU PORNIRE ADRESA

		if(strcmp(argv[1], "-a") == 0) {

			int i = 0;	
			struct in_addr addr;
			inet_aton(argv[2], &addr);

			//  struct hostent* host = gethostbyaddr(const char*addr, int len, int type )  //-- returnreaza null daca nu gseste
			struct hostent* host = gethostbyaddr(&addr, sizeof(addr), AF_INET);  // TIPUL de protocol
			
			if(host == NULL)
				perror("Nu e host ul bun");
			else {

				printf("Numele referentiat : %s \n", host->h_name);

				for(i = 0; host->h_aliases[i] != NULL; i++)
					printf("%s \n", host->h_aliases[i]);


			}
			}

			

	}
		


}


