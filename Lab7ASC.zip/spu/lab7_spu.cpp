/*
 * Computer Systems Architecture - Lab 7 (2017)
 * SPU code 
 */

#include <stdio.h>
#include <spu_intrinsics.h>

#define N  16

float A[N] __attribute__ ((aligned(N))) =  {  
	  20.0,   40.0,  80.0, 100.0,
	 120.0,  140.0, 160.0, 180.0,
	  40.0,   60.0,  60.0,  40.0,
	 100.0,  120.0, 120.0, 100.0}; 

float B[N] __attribute__ ((aligned(N))) = {
	1.0, -1.0, 0.0, 0.0,
	1.0, -1.0, 0.0, 0.0,
	1.0, -1.0, 0.0, 0.0,
	1.0, -1.0, 0.0, 0.0,
}; 

float C[N] __attribute__ ((aligned(N))) = {
	  40.0,   40.0,  80.0, 100.0,
	 140.0,  140.0, 160.0, 180.0,
	  60.0,   60.0,  60.0,  40.0,
	 120.0,  120.0, 120.0, 100.0
}; 

/* 
 * Print an array of vector float variables with the given length. 
 * !!! Don't use for scalar arrays !!!
 */
void print_vector_float(vector float *v, int length) 
{
	int i;
	for (i = 0; i < length; i+=1)
		printf("%.2lf %.2lf %.2lf %.2lf ", v[i][0], v[i][1], v[i][2], v[i][3]);
	printf("\n");
}
/* 
 * Print an array of vector unsigned int variables with the given length. 
 * !!! Don't use for scalar arrays !!!
 */
void print_vector_uint(vector unsigned int *v, int length) 
{
	int i;
	for (i = 0; i < length; i+=1)
		printf("%u %u %u %u ", v[i][0], v[i][1], v[i][2], v[i][3]);
	printf("\n");
}

void task5()
{

	//TODO Task 5

	// 'transform' scalar arrays A, B, C to vector arrays: a, b, c

	//int n = N/4;

	//vector float scale_factor = spu_splats(20.0f);
	//vector float res[n];
	//vector unsigned int cmp_res[n];
        
        // res = b * scale_factor + a 

	// compare res and c

	// print a, b, c, res, cmp_res	
		
}
int main(unsigned long long speid, 
		unsigned long long argp, 
		unsigned long long envp) 
{

	speid = speid;
	argp = argp;
	envp = envp; // silence warnings

	printf("Hello World! from Cell id : %llu  (%llu)\n", argp, speid);

	//TODO Task 4 - print the spe index received as argument

	task5();

	return 0;
}
