#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>


void *PrintHello(void *threadid)
{
   long id;
   id = (long)threadid;
   printf("Hello World from thread %ld!\n", id);
   pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
   pthread_t threads[10];
   int rc;
   long i;
   for(i = 0; i < 10; i++){
     rc = pthread_create(&threads[i], NULL, PrintHello, (void *)i);
     if (rc){
       printf("ERROR");
       exit(-1);
       }
     }
	for(i = 0; i < 10; i++){
		   pthread_join(threads[i],NULL);
	}
   pthread_exit(NULL);
}
